package servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.text.ParseException;

import mantenimientos.GestionProducto;
import model.Productos;

@WebServlet("/inventarioServlet")
public class InventarioServelt extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public InventarioServelt() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String opcion = request.getParameter("opcion");
        
        System.out.println("opcion: " + opcion);
        
        if (opcion != null) {
            switch(opcion) {
                case "reg":
                    registrar(request, response);
                    break;
                    
                default:
                    throw new IllegalArgumentException("Opción no válida: " + opcion);
            }
        } else {
            throw new IllegalArgumentException("Parámetro 'opcion' no especificado");
        }
    }

    private void registrar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String mensaje = "";

        try {
            int codigo = Integer.parseInt(request.getParameter("txtCodigo"));
            String descripcion = request.getParameter("txtDescripcion");
            String talla = request.getParameter("txtTalla");
            int cantidad = Integer.parseInt(request.getParameter("txtCantidad"));
            String fechaStr = request.getParameter("txtfecha");

            DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            Date fecha = dateFormat.parse(fechaStr);

            Productos objEntrada = new Productos(codigo, descripcion, talla, cantidad, fecha);

            GestionProducto gestionProducto = new GestionProducto();
            int ok = gestionProducto.registrar(objEntrada);
            
            if (ok == 0) {
                mensaje += "<script>alert('Error al registrar los datos');</script>";
            } else {
                mensaje += "<script>alert('Registro exitoso');</script>";
            }
        } catch (ParseException e) {
            e.printStackTrace();
            mensaje += "<script>alert('Error al convertir la fecha');</script>";
        } catch (NumberFormatException e) {
            e.printStackTrace();
            mensaje += "<script>alert('Error al convertir los números');</script>";
        }
        
        request.setAttribute("mensaje", mensaje);
        request.getRequestDispatcher("producto/Entradas.jsp").forward(request, response);
    }
}
