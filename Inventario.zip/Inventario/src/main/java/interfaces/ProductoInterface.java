package interfaces;

import model.Productos;

public interface ProductoInterface {

	
	public int registrar(Productos productos);
}
