package model;
import java.util.Date;

public class Productos {
    private int codigo;
    private String descripcion;
    private String talla;
    private int cantidad;
    private Date fecha;

    // Constructor
    public Productos(int codigo, String descripcion, String talla, int cantidad, Date fecha) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.talla = talla;
        this.cantidad = cantidad;
        this.fecha = fecha;
    }

    // Getters y Setters
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }
}
