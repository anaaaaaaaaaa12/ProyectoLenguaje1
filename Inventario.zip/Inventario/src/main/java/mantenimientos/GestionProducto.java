package mantenimientos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import interfaces.ProductoInterface;
import model.Productos;
import util.MySQLConexion;

public class GestionProducto implements ProductoInterface {

	@Override
	public int registrar(Productos productos) {
	    // Declaración de variables
	    int rs = 0;
	    Connection con = null;
	    PreparedStatement pst = null;

	    try {
	        // Obtener la conexión a la base de datos
	        con = MySQLConexion.getConexion();
	        String sql = "INSERT INTO bd_entradas_epp VALUES (null, ?, ?, ?, ?, ?)";
	        pst = con.prepareStatement(sql);

	        // Establecer los valores en el PreparedStatement
	        pst.setInt(1, productos.getCodigo());
	        pst.setString(2, productos.getDescripcion());
	        pst.setString(3, productos.getTalla());
	        pst.setInt(4, productos.getCantidad());

	        // Convertir la fecha de java.util.Date a java.sql.Date
	        java.sql.Date fechaSQL = new java.sql.Date(productos.getFecha().getTime());
	        pst.setDate(5, fechaSQL);

	        // Ejecutar la consulta
	        rs = pst.executeUpdate();

	    } catch (SQLException e) {
	        // Manejar la excepción
	    	System.out.println("Error en la sentencia "+e.getMessage());
	        
	    } finally {
	        // Cerrar la conexión en el bloque finally para liberar recursos
	        try {
	            if (pst != null)pst.close(); {
	            }
	            if (con != null)con.close();{
	                
	            }
	        } catch (SQLException e2) {
	            // Manejar la excepción al cerrar la conexión
	        	System.out.println("Error al cerrar "+e2.getMessage());
	        }
	    }

	    return rs;
	}
}