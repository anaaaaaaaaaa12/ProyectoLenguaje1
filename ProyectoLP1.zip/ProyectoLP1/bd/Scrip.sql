-- Borra la BD si existe
DROP DATABASE IF EXISTS bd_registro_trabajadores;

-- Crea la BD
CREATE DATABASE bd_registro_trabajadores;

-- Activa la BD
USE bd_registro_trabajadores;

-- Tabla de puestos laborales
CREATE TABLE tb_puestos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(255) NOT NULL
);

-- Inserta algunos puestos laborales
INSERT INTO tb_puestos (nombre) VALUES
('Administrador'),
('Contador'),
('Planner'),
('Analista de costos'),
('Mecánico'),
('Asistente Administrativo');

-- Tabla de trabajadores
CREATE TABLE tb_trabajadores (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombres VARCHAR(255) NOT NULL,
    apellidoPaterno VARCHAR(100) NOT NULL,
    apellidoMaterno VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    celular NUMERIC NOT NULL,
    id_puesto INT,
    CONSTRAINT fk_id_puesto FOREIGN KEY (id_puesto) REFERENCES tb_puestos(id)
);

-- Inserta algunos trabajadores
INSERT INTO tb_trabajadores (nombres, apellidoPaterno, apellidoMaterno, email, celular, id_puesto) VALUES
('Carlos', 'Gomez', 'Lopez', 'carlos@gmail.com', 987654321, 1),
('Ana', 'Rodriguez', 'Perez', 'ana@gmail.com', 945123678, 2),
('Juan', 'Lopez', 'Martinez', 'juan@gmail.com', 958746123, 3),
('Luis', 'Fernandez', 'Torres', 'luis@gmail.com', 912345678, 4);

-- Verifica los datos
SELECT * FROM tb_trabajadores;
