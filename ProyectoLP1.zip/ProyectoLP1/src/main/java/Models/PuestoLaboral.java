package Models;

public class PuestoLaboral {
    
    private int codigo;
    private String PuestoLaboral;

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getPuestoLaboral() {
        return PuestoLaboral;
    }

    public void setPuestoLaboral(String PuestoLaboral) {
        this.PuestoLaboral = PuestoLaboral;
    }   
}

