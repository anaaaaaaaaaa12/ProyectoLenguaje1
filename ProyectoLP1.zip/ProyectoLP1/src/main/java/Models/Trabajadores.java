package Models;

import Models.PuestoLaboral;

public class Trabajadores {
	public int IDTrabajador;
	public String Nombres;
	public String ApellidoPaterno;
	public String ApellidoMaterno;
	private String email;
	private long celular;
	private PuestoLaboral puesto;
	
	public Trabajadores(int iDTrabajador, String nombres, String apellidoPaterno, String apellidoMaterno, String email,
			long celular, PuestoLaboral puesto) {
		super();
		IDTrabajador = iDTrabajador;
		Nombres = nombres;
		ApellidoPaterno = apellidoPaterno;
		ApellidoMaterno = apellidoMaterno;
		this.email = email;
		this.celular = celular;
		this.puesto = puesto;
	}
	

	public Trabajadores(String nombres, String apellidoPaterno, String apellidoMaterno, String email, long celular,
			PuestoLaboral puesto) {
		super();
		Nombres = nombres;
		ApellidoPaterno = apellidoPaterno;
		ApellidoMaterno = apellidoMaterno;
		this.email = email;
		this.celular = celular;
		this.puesto = puesto;
	}


	public int getIDTrabajador() {
		return IDTrabajador;
	}

	public void setIDTrabajador(int iDTrabajador) {
		IDTrabajador = iDTrabajador;
	}

	public String getNombres() {
		return Nombres;
	}

	public void setNombres(String nombres) {
		Nombres = nombres;
	}

	public String getApellidoPaterno() {
		return ApellidoPaterno;
	}

	public void setApellidoPaterno(String apellidoPaterno) {
		ApellidoPaterno = apellidoPaterno;
	}

	public String getApellidoMaterno() {
		return ApellidoMaterno;
	}

	public void setApellidoMaterno(String apellidoMaterno) {
		ApellidoMaterno = apellidoMaterno;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getCelular() {
		return celular;
	}

	public void setCelular(long celular) {
		this.celular = celular;
	}

	public PuestoLaboral getPuesto() {
		return puesto;
	}

	public void setPuesto(PuestoLaboral puesto) {
		this.puesto = puesto;
	}
	

}

